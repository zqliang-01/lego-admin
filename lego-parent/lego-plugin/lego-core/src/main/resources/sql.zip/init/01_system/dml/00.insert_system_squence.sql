INSERT INTO sys_sequence(ID, NAME) VALUES (1, 'general');
INSERT INTO sys_sequence(ID, NAME) VALUES (1, 'employee');
INSERT INTO sys_sequence(ID, NAME) VALUES (1, 'business');