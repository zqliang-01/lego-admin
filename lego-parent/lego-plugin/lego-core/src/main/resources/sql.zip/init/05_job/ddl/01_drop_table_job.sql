
DROP TABLE IF EXISTS xxl_job_info;

DROP TABLE IF EXISTS xxl_job_log;

DROP TABLE IF EXISTS xxl_job_log_report;

DROP TABLE IF EXISTS xxl_job_logglue;

DROP TABLE IF EXISTS xxl_job_registry;

DROP TABLE IF EXISTS xxl_job_group;

DROP TABLE IF EXISTS xxl_job_user;

DROP TABLE IF EXISTS xxl_job_lock;