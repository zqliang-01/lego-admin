DROP VIEW IF EXISTS sys_schema_table;

DROP VIEW IF EXISTS sys_schema_column;

DROP VIEW IF EXISTS sys_schema_db;