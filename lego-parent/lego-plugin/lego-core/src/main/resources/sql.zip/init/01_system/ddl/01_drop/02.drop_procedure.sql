DROP PROCEDURE IF EXISTS add_sharding_template;
DROP PROCEDURE IF EXISTS add_system_permission;