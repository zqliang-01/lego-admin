DROP PROCEDURE IF EXISTS add_sharding_algorithm_properties;
DROP PROCEDURE IF EXISTS add_sharding_algorithm;
DROP PROCEDURE IF EXISTS add_sharding_datasource_properties;
DROP PROCEDURE IF EXISTS add_sharding_datasource;
DROP PROCEDURE IF EXISTS add_sharding_table;