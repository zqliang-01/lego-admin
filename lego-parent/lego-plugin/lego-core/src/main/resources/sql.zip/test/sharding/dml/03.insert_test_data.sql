INSERT INTO test_order_1(id, NAME, create_time) VALUE (1, 'order001', SYSDATE());
INSERT INTO test_order_0(id, NAME, create_time) VALUE (2, 'order002', SYSDATE());
INSERT INTO test_order_1(id, NAME, create_time) VALUE (3, 'order003', SYSDATE());
INSERT INTO test_order_0(id, NAME, create_time) VALUE (4, 'order004', SYSDATE());
INSERT INTO test_order_1(id, NAME, create_time) VALUE (5, 'order005', SYSDATE());
INSERT INTO test_order_0(id, NAME, create_time) VALUE (6, 'order006', SYSDATE());
INSERT INTO test_order_1(id, NAME, create_time) VALUE (7, 'order007', SYSDATE());
INSERT INTO test_order_0(id, NAME, create_time) VALUE (8, 'order008', SYSDATE());
INSERT INTO test_order_1(id, NAME, create_time) VALUE (9, 'order009', SYSDATE());
INSERT INTO test_order_0(id, NAME, create_time) VALUE (10, 'order010', SYSDATE());

INSERT INTO test_log_202304(id, name, create_time) VALUES (1, '日志20230401', '2023-04-05 15:14:28');
INSERT INTO test_log_202304(id, name, create_time) VALUES (2, '日志20230402', '2023-04-08 08:50:35');
INSERT INTO test_log_202305(id, name, create_time) VALUES (3, '日志02030501', '2023-05-10 16:25:57');
INSERT INTO test_log_202305(id, name, create_time) VALUES (4, '日志02030502', '2023-02-10 13:56:12');
INSERT INTO test_log_202306(id, name, create_time) VALUES (5, '日志20230601', '2023-06-03 06:16:22');